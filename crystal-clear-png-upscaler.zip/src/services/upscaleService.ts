/**
 * Upscale Service for Hugging Face ZeroGPU Gradio Space Integration.
 * 
 * This service handles communication with a remote Gradio backend.
 * Alpha transparency of PNG files is strictly preserved by transmitting
 * native PNG blobs and receiving raw PNG outputs.
 */

import { Client } from "@gradio/client";

export interface UpscaleResult {
  outputUrl: string;
  outputBlob: Blob;
  outputWidth: number;
  outputHeight: number;
  outputSize: number;
}

/**
 * Checks if the backend URL is configured and non-empty.
 */
export function isBackendConfigured(backendUrl: string): boolean {
  if (!backendUrl) return false;
  const trimmed = backendUrl.trim();
  return (
    trimmed.length > 0 &&
    !trimmed.includes("user-space.hf.space") &&
    !trimmed.includes("your-username-your-space") &&
    (trimmed.startsWith("http://") || trimmed.startsWith("https://"))
  );
}

/**
 * Normalizes backend URL (removes trailing slashes)
 */
export function normalizeUrl(url: string): string {
  return url.trim().replace(/\/+$/, "");
}

/**
 * Tests connection to the remote Gradio Space
 */
export async function testBackendConnection(
  backendUrl: string,
  hfToken?: string
): Promise<{ ok: boolean; message: string; details?: any }> {
  if (!backendUrl || !backendUrl.trim()) {
    return { ok: false, message: "Backend URL is empty. Please enter your Hugging Face Space URL." };
  }

  const cleanUrl = normalizeUrl(backendUrl);

  try {
    // 1. First attempt quick health check on config or info
    const headers: Record<string, string> = {};
    if (hfToken) {
      headers["Authorization"] = `Bearer ${hfToken}`;
    }

    // Try Gradio client connect
    const clientOptions: any = {};
    if (hfToken) {
      clientOptions.hf_token = hfToken;
    }

    const app = await Client.connect(cleanUrl, clientOptions);
    const viewApi = await app.view_api();

    return {
      ok: true,
      message: "Successfully connected to Gradio Space!",
      details: viewApi
    };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);

    // Provide friendly diagnostics
    if (errorMsg.includes("Failed to fetch") || errorMsg.includes("NetworkError") || errorMsg.includes("CORS")) {
      return {
        ok: false,
        message: "Network or CORS error. Make sure the Hugging Face Space is set to 'Public' and the URL is correct (e.g. https://<user>-<space>.hf.space)."
      };
    }

    if (errorMsg.includes("404")) {
      return {
        ok: false,
        message: "Space returned 404. Verify the URL matches your Hugging Face Space direct domain."
      };
    }

    if (errorMsg.includes("503") || errorMsg.includes("sleeping")) {
      return {
        ok: false,
        message: "Hugging Face Space is currently sleeping or restarting. Open the space in a new tab to wake it up."
      };
    }

    return {
      ok: false,
      message: `Connection failed: ${errorMsg}`
    };
  }
}

/**
 * Performs actual AI image upscaling via Gradio ZeroGPU space
 */
export async function upscaleImage(
  imageBlob: Blob,
  factor: number,
  backendUrl: string,
  options?: {
    endpoint?: string;
    hfToken?: string;
    onProgress?: (percent: number) => void;
  }
): Promise<UpscaleResult> {
  if (!backendUrl || !backendUrl.trim()) {
    throw new Error(
      "Hugging Face Backend URL is not configured. Please open Settings and paste your Space URL (e.g. https://your-username-space.hf.space)."
    );
  }

  const cleanUrl = normalizeUrl(backendUrl);
  const endpoint = options?.endpoint || "/predict";
  const hfToken = options?.hfToken;

  options?.onProgress?.(15);

  try {
    // Connect to Gradio Space
    const clientOptions: any = {};
    if (hfToken) {
      clientOptions.hf_token = hfToken;
    }

    const app = await Client.connect(cleanUrl, clientOptions);
    options?.onProgress?.(35);

    // Gradio predict call.
    // Try primary argument signature (object or positional array).
    let result: any;
    try {
      // Common Gradio image-to-image with upscale factor: [image, factor]
      result = await app.predict(endpoint, [imageBlob, factor]);
    } catch (firstErr: any) {
      // Fallback 1: try string factor
      try {
        result = await app.predict(endpoint, [imageBlob, String(factor)]);
      } catch (secondErr: any) {
        // Fallback 2: try named object
        try {
          result = await app.predict(endpoint, {
            image: imageBlob,
            input_image: imageBlob,
            upscale_factor: factor,
            scale: factor
          } as any);
        } catch (thirdErr: any) {
          // Fallback 3: try with single image parameter
          result = await app.predict(endpoint, [imageBlob]);
        }
      }
    }

    options?.onProgress?.(75);

    if (!result || !result.data) {
      throw new Error("Invalid response format received from Gradio backend");
    }

    // Extract image output from Gradio output
    const outputData = Array.isArray(result.data) ? result.data[0] : result.data;
    let rawImageUrl = "";

    if (typeof outputData === "string") {
      rawImageUrl = outputData;
    } else if (outputData && typeof outputData === "object") {
      rawImageUrl = outputData.url || outputData.path || outputData.data || "";
    }

    if (!rawImageUrl) {
      throw new Error("Gradio completed without returning an image URL");
    }

    // If it's a relative URL, prepend backend base URL
    if (rawImageUrl.startsWith("/")) {
      rawImageUrl = `${cleanUrl}${rawImageUrl}`;
    }

    // Fetch the resulting PNG as a Blob to verify data and preserve PNG alpha
    const fetchHeaders: Record<string, string> = {};
    if (hfToken) {
      fetchHeaders["Authorization"] = `Bearer ${hfToken}`;
    }

    const response = await fetch(rawImageUrl, { headers: fetchHeaders });
    if (!response.ok) {
      throw new Error(`Failed to retrieve generated image file: HTTP ${response.status}`);
    }

    const downloadedBlob = await response.blob();
    // Ensure blob is PNG mime type
    const pngBlob = new Blob([downloadedBlob], { type: "image/png" });
    const localBlobUrl = URL.createObjectURL(pngBlob);

    // Measure dimensions of the resulting image
    const dimensions = await getImageDimensions(localBlobUrl);

    options?.onProgress?.(100);

    return {
      outputUrl: localBlobUrl,
      outputBlob: pngBlob,
      outputWidth: dimensions.width,
      outputHeight: dimensions.height,
      outputSize: pngBlob.size
    };
  } catch (error: any) {
    console.error("ZeroGPU Gradio Upscale Error:", error);

    const msg = error?.message || String(error);
    if (msg.includes("Failed to fetch") || msg.includes("CORS")) {
      throw new Error(
        `Unable to reach Gradio backend at ${cleanUrl}. Check CORS permissions and verify your Hugging Face space is awake.`
      );
    }
    if (msg.includes("Queue full") || msg.includes("GPU busy")) {
      throw new Error("ZeroGPU is currently under heavy load. Please retry in a few moments.");
    }
    throw new Error(msg);
  }
}

/**
 * Loads image into memory to get true pixel dimensions
 */
export function getImageDimensions(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      resolve({ width: img.naturalWidth || img.width, height: img.naturalHeight || img.height });
    };
    img.onerror = () => {
      reject(new Error("Failed to read image dimensions"));
    };
    img.src = url;
  });
}

/**
 * Helper to download a single file directly
 */
export function downloadFile(url: string, filename: string) {
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Format bytes to readable string (e.g. 1.2 MB)
 */
export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}
